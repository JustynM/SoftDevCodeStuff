<?php
    include('functions.php');
    $content = 'home.html';
    //make_basic_page('Home', $content, null);
    make_page('Home', null, 'home.html', null, $style = null)
?>